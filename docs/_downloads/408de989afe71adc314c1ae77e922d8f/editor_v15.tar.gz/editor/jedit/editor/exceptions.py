class NotSupportedException(Exception):
    """Raised when % matplotlib notebook is not set"""
    pass
