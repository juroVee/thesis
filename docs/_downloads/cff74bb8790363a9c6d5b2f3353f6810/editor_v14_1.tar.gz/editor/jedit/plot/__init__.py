from .function import Function
from .function_manager import FunctionManager
from .painter import Painter
from .calculations import Calculator