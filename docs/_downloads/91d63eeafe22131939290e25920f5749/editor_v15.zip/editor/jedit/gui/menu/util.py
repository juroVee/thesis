def logger_message(theme, **kwargs):
    return theme, kwargs