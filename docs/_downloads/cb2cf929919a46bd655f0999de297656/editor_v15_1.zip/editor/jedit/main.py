from .editor import Editor


def editor(**params):
    Editor().run_instance(**params)
