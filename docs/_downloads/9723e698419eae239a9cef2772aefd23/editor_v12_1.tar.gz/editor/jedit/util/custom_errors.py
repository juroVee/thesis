class NotSupportedException(Exception):
    """Raised when % matplotlib notebook is not set"""
    pass

class MissingParameterException(Exception):
    """Raised when % matplotlib notebook is not set"""
    pass