import ipywidgets as w

# ----------- save button ----------

#TODO
button_save = w.Button(
    description='Save',
    disabled=False,
    button_style='', # 'success', 'info', 'warning', 'danger' or ''
    tooltip='Save settings'
)