from .function import Function
from .manager import Manager
from .painter import Painter
from .calculations import Calculator